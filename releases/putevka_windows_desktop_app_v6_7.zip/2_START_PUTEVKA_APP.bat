@echo off
pushd "%~dp0"
start "" wscript.exe "Putevka_Desktop.vbs"
popd
