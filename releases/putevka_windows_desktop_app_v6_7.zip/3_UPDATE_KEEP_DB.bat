@echo off
pushd "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts_win\install_desktop_app.ps1" -BuildExe -KeepDb
popd
pause
