param(
    [switch]$BuildExe = $true,
    [switch]$KeepDb = $false
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$AppVersion = "v6.7.0"
$ProjectRoot = if (Test-Path "$PSScriptRoot\desktop_app.py") { $PSScriptRoot } else { Split-Path -Parent $PSScriptRoot }
Set-Location $ProjectRoot

function Write-Step($msg) { Write-Host "[INFO]  $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "[ OK ]  $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN]  $msg" -ForegroundColor Yellow }

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  АСУ «ПУТЁВКА» $AppVersion — Установка Десктопного Приложения Windows" -ForegroundColor Cyan
Write-Host "  Директория приложения: $ProjectRoot" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# 1. Проверка и автоустановка Python 3.11
$PyCmd = Get-Command python -ErrorAction SilentlyContinue
$PyOk = $false
if ($PyCmd) {
    try {
        $verOut = & python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        if ($LASTEXITCODE -eq 0 -and $verOut) { $PyOk = $true }
    } catch {}
}

if (-not $PyOk) {
    Write-Warn "Python 3 не найден. Выполняется автоматическая установка Python 3.11..."
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install -e --id Python.Python.3.11 --scope machine --accept-package-agreements --accept-source-agreements
    } else {
        $PyUrl = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
        $PyInstaller = Join-Path $env:TEMP "python-3.11.9-amd64.exe"
        Write-Step "Скачивание установщика Python 3.11.9..."
        Invoke-WebRequest -Uri $PyUrl -OutFile $PyInstaller -UseBasicParsing
        Start-Process -FilePath $PyInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0" -Wait
    }
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
}

$PyVerFull = & python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')"
Write-Ok "Python готов: версия $PyVerFull"

# 2. Инициализация базы данных
$DbFile = Join-Path $ProjectRoot "data\putevka_db.json"
$InitFile = Join-Path $ProjectRoot "data\app_data.json"
if (-not $KeepDb -or -not (Test-Path $DbFile)) {
    Copy-Item $InitFile $DbFile -Force
    Write-Ok "Рабочая база данных инициализирована."
} else {
    Write-Ok "Сохранена текущая рабочая база данных data\putevka_db.json."
}

# 3. Создание виртуального окружения venv и установка pywebview + зависимостей
$VenvPy = Join-Path $ProjectRoot "venv\Scripts\python.exe"
$VenvPip = Join-Path $ProjectRoot "venv\Scripts\pip.exe"
$VenvPyInstaller = Join-Path $ProjectRoot "venv\Scripts\pyinstaller.exe"

if (-not (Test-Path $VenvPy)) {
    Write-Step "Создание виртуального окружения приложения (venv)..."
    & python -m venv "$ProjectRoot\venv"
}

Write-Step "Установка компонентов десктопного приложения (FastAPI, OpenPyXL, PyWebView, PyInstaller)..."
& $VenvPy -m pip install --upgrade pip setuptools wheel --quiet
& $VenvPip install -r "$ProjectRoot\requirements.txt" --quiet
try {
    & $VenvPip install pywebview pyinstaller --quiet
} catch {
    Write-Warn "Установка дополнительных пакетов pywebview/pyinstaller пропущена, используется встроенный оконный движок."
}

# 4. Сборка нативного исполняемого файла Putevka.exe (без консоли, с иконкой putevka.ico)
$ExeTarget = Join-Path $ProjectRoot "dist\Putevka\Putevka.exe"
if ($BuildExe -and (Test-Path $VenvPyInstaller)) {
    Write-Step "Компиляция нативного приложения Windows (Putevka.exe)..."
    try {
        & $VenvPyInstaller --noconfirm --onedir --windowed --name "Putevka" `
            --icon "$ProjectRoot\putevka.ico" `
            --add-data "$ProjectRoot\static;static" `
            --add-data "$ProjectRoot\data;data" `
            --add-data "$ProjectRoot\templates_xls;templates_xls" `
            "$ProjectRoot\desktop_app.py" | Out-Null
        if (Test-Path $ExeTarget) {
            Copy-Item "$ProjectRoot\data\*" (Join-Path $ProjectRoot "dist\Putevka\data") -Recurse -Force -ErrorAction SilentlyContinue
            Write-Ok "Скомпилирован исполняемый файл приложения: $ExeTarget"
        }
    } catch {
        Write-Warn "Компиляция .exe пропущена ($($_.Exception.Message)), приложение будет запускаться через Putevka_Desktop.vbs"
    }
}

# 5. Создание ярлыка Десктопного Приложения на Рабочем столе и в Меню Пуск (с фирменной иконкой putevka.ico)
try {
    $WshShell = New-Object -ComObject WScript.Shell
    $IconFile = Join-Path $ProjectRoot "putevka.ico"

    foreach ($Folder in @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Programs"))) {
        $LnkPath = Join-Path $Folder "ПУТЁВКА $AppVersion.lnk"
        $Shortcut = $WshShell.CreateShortcut($LnkPath)
        if (Test-Path $ExeTarget) {
            $Shortcut.TargetPath = $ExeTarget
            $Shortcut.WorkingDirectory = Split-Path -Parent $ExeTarget
        } else {
            $Shortcut.TargetPath = "wscript.exe"
            $Shortcut.Arguments = "`"$ProjectRoot\Putevka_Desktop.vbs`""
            $Shortcut.WorkingDirectory = $ProjectRoot
        }
        $Shortcut.IconLocation = "$IconFile,0"
        $Shortcut.Description = "Десктопное приложение АСУ ПУТЁВКА $AppVersion (Форма 0345001)"
        $Shortcut.Save()
    }
    Write-Ok "На Рабочем столе и в Меню Пуск создан ярлык приложения «ПУТЁВКА $AppVersion»!"
} catch {
    Write-Warn "Не удалось создать ярлык: $($_.Exception.Message)"
}

Write-Host "==================================================================" -ForegroundColor Green
Write-Host "  >>> УСПЕШНО! Десктопное приложение «ПУТЁВКА $AppVersion» установлено!" -ForegroundColor Green
Write-Host "  Ярлык приложения находится на Рабочем столе Windows." -ForegroundColor Cyan
Write-Host "  Запускаем окно приложения..." -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Green

Start-Process -FilePath "wscript.exe" -ArgumentList "`"$ProjectRoot\Putevka_Desktop.vbs`"" -WorkingDirectory $ProjectRoot
