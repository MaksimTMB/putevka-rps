Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = appDir

exeOneFile = appDir & "\dist\Putevka_Windows_v6_7.exe"
exePath = appDir & "\dist\Putevka\Putevka.exe"
pywPath = appDir & "\venv\Scripts\pythonw.exe"
pyPath  = appDir & "\venv\Scripts\python.exe"

If fso.FileExists(exeOneFile) Then
    shell.Run """" & exeOneFile & """", 1, False
ElseIf fso.FileExists(exePath) Then
    shell.Run """" & exePath & """", 1, False
ElseIf fso.FileExists(pywPath) Then
    shell.Run """" & pywPath & """ """ & appDir & "\desktop_app.py""", 0, False
ElseIf fso.FileExists(pyPath) Then
    shell.Run """" & pyPath & """ """ & appDir & "\desktop_app.py""", 0, False
Else
    MsgBox "Desktop App is not installed yet. Please run 1_INSTALL_WINDOWS_APP.bat first.", 48, "ASU PUTEVKA v6.7.0"
End If
