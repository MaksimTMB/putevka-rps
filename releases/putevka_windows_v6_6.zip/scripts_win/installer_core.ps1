param(
    [string]$Action = "install",
    [switch]$KeepDb = $false,
    [int]$Port = 8080
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$AppVersion = "v6.6.0"
$ProjectRoot = if (Test-Path "$PSScriptRoot\server.py") { $PSScriptRoot } else { Split-Path -Parent $PSScriptRoot }
Set-Location $ProjectRoot

function Write-Step($msg) { Write-Host "[INFO]  $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "[ OK ]  $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN]  $msg" -ForegroundColor Yellow }

if ($Action -eq "stop") {
    Write-Step "Остановка сервера АСУ «ПУТЁВКА» на порту $Port..."
    Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue | ForEach-Object {
        Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue
    }
    Write-Ok "Сервер на порту $Port остановлен."
    exit 0
}

if ($Action -eq "autostart") {
    $VenvPyw = Join-Path $ProjectRoot "venv\Scripts\pythonw.exe"
    if (-not (Test-Path $VenvPyw)) { $VenvPyw = Join-Path $ProjectRoot "venv\Scripts\python.exe" }
    Write-Step "Регистрация автозапуска АСУ «ПУТЁВКА» в Планировщике заданий Windows..."
    $TaskAction = New-ScheduledTaskAction -Execute $VenvPyw -Argument "`"$ProjectRoot\server.py`"" -WorkingDirectory $ProjectRoot
    $Trigger = New-ScheduledTaskTrigger -AtLogOn
    Register-ScheduledTask -TaskName "ASU_Putevka_Server" -Action $TaskAction -Trigger $Trigger -Description "Автозапуск сервера АСУ ПУТЁВКА $AppVersion" -Force | Out-Null
    Write-Ok "Задача автозапуска 'ASU_Putevka_Server' успешно зарегистрирована!"
    exit 0
}

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "  АСУ «ПУТЁВКА» $AppVersion — Мастер установки и запуска для Windows" -ForegroundColor Cyan
Write-Host "  Папка программы: $ProjectRoot" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan

# ШАГ 1. Проверка и автоустановка Python 3
$PyCmd = Get-Command python -ErrorAction SilentlyContinue
$PyOk = $false
if ($PyCmd) {
    try {
        $verOut = & python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        if ($LASTEXITCODE -eq 0 -and $verOut) { $PyOk = $true }
    } catch {}
}

if (-not $PyOk) {
    Write-Warn "Python 3 не обнаружен в системе. Запускаем автоматическую установку Python 3.11..."
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install -e --id Python.Python.3.11 --scope machine --accept-package-agreements --accept-source-agreements
    } else {
        $PyUrl = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
        $PyInstaller = Join-Path $env:TEMP "python-3.11.9-amd64.exe"
        Write-Step "Скачивание официального установщика Python 3.11.9 с python.org..."
        Invoke-WebRequest -Uri $PyUrl -OutFile $PyInstaller -UseBasicParsing
        Write-Step "Тихая установка Python 3.11.9 (с добавлением в PATH)..."
        Start-Process -FilePath $PyInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0" -Wait
    }
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
}

$PyVerFull = & python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')"
Write-Ok "Python проверен и готов к работе: версия $PyVerFull"

# ШАГ 2. Проверка целостности файлов проекта
$ReqFiles = @("server.py", "requirements.txt", "static\index.html", "templates_xls\template_0345001.xlsx", "data\app_data.json")
foreach ($rf in $ReqFiles) {
    $fp = Join-Path $ProjectRoot $rf
    if (-not (Test-Path $fp)) {
        throw "Отсутствует обязательный файл проекта: $fp"
    }
}
Write-Ok "Целостность всех файлов дистрибутива проверена."

# ШАГ 3. Инициализация или сохранение рабочей базы данных
$DbFile = Join-Path $ProjectRoot "data\putevka_db.json"
$InitFile = Join-Path $ProjectRoot "data\app_data.json"
if (-not $KeepDb -or -not (Test-Path $DbFile)) {
    Copy-Item $InitFile $DbFile -Force
    Write-Ok "База данных инициализирована эталоном релиза $AppVersion (активна первичная регистрация Администратора)."
} else {
    Write-Ok "Сохранена существующая рабочая база данных data\putevka_db.json."
}

# ШАГ 4. Создание виртуального окружения venv и установка библиотек
$VenvPy = Join-Path $ProjectRoot "venv\Scripts\python.exe"
$VenvPyw = Join-Path $ProjectRoot "venv\Scripts\pythonw.exe"
$VenvPip = Join-Path $ProjectRoot "venv\Scripts\pip.exe"

if (-not (Test-Path $VenvPy)) {
    Write-Step "Создание изолированного виртуального окружения (venv)..."
    & python -m venv "$ProjectRoot\venv"
}

Write-Step "Проверка и установка библиотек (fastapi, uvicorn, openpyxl, pydantic)..."
& $VenvPy -m pip install --upgrade pip setuptools wheel --quiet
& $VenvPip install -r "$ProjectRoot\requirements.txt" --quiet

& $VenvPy -c "import fastapi, uvicorn, openpyxl, pydantic, server; assert server.APP_VERSION == '$AppVersion'"
Write-Ok "Все библиотеки установлены и проверены (версия сервера: $AppVersion)."

# ШАГ 5. Создание ярлыков на Рабочем столе Windows
try {
    $DesktopDir = [Environment]::GetFolderPath("Desktop")
    $WshShell = New-Object -ComObject WScript.Shell

    $ShortcutStart = $WshShell.CreateShortcut((Join-Path $DesktopDir "ПУТЁВКА $AppVersion — Запуск.lnk"))
    $ShortcutStart.TargetPath = Join-Path $ProjectRoot "2_ЗАПУСТИТЬ_СЕРВЕР.bat"
    $ShortcutStart.WorkingDirectory = $ProjectRoot
    $ShortcutStart.IconLocation = "shell32.dll,13"
    $ShortcutStart.Description = "Запуск сервера АСУ ПУТЁВКА $AppVersion и открытие в браузере"
    $ShortcutStart.Save()

    $ShortcutWeb = $WshShell.CreateShortcut((Join-Path $DesktopDir "ПУТЁВКА $AppVersion — Веб-панель.url"))
    $ShortcutWeb.TargetPath = "http://localhost:$Port"
    $ShortcutWeb.Save()

    Write-Ok "Ярлыки «ПУТЁВКА $AppVersion — Запуск» и «Веб-панель» созданы на Рабочем столе."
} catch {
    Write-Warn "Не удалось создать ярлык на Рабочем столе: $($_.Exception.Message)"
}

# ШАГ 6. Освобождение порта 8080, настройка брандмауэра и запуск сервера
Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue | ForEach-Object {
    Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue
}
try {
    New-NetFirewallRule -DisplayName "ASU Putevka $Port" -Direction Inbound -LocalPort $Port -Protocol TCP -Action Allow -ErrorAction SilentlyContinue | Out-Null
    Write-Ok "Порт $Port/TCP разрешен в Брандмауэре Windows."
} catch {}

Write-Step "Запуск фонового сервера АСУ «ПУТЁВКА» $AppVersion на порту $Port..."
$RunnerExe = if (Test-Path $VenvPyw) { $VenvPyw } else { $VenvPy }
$Proc = Start-Process -FilePath $RunnerExe -ArgumentList "`"$ProjectRoot\server.py`"" -WorkingDirectory $ProjectRoot -PassThru -WindowStyle Hidden

$HealthOk = $false
for ($i = 0; $i -lt 8; $i++) {
    Start-Sleep -Seconds 1
    try {
        $resp = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/state" -TimeoutSec 3
        if ($null -ne $resp.profiles) {
            $HealthOk = $true
            break
        }
    } catch {}
}

if (-not $HealthOk) {
    throw "Сервер не ответил на контрольный HTTP-запрос http://127.0.0.1:$Port/api/state"
}

Write-Host "==================================================================" -ForegroundColor Green
Write-Host "  >>> УСПЕШНО! АСУ «ПУТЁВКА» $AppVersion установлена и запущена!" -ForegroundColor Green
Write-Host "  PID процесса:     $($Proc.Id)" -ForegroundColor White
Write-Host "  Папка установки:  $ProjectRoot" -ForegroundColor White
Write-Host "  Адрес в браузере: http://localhost:$Port" -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Green

Start-Process "http://localhost:$Port"
