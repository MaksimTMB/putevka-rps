Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = appDir

exePath = appDir & "\dist\Putevka\Putevka.exe"
pywPath = appDir & "\venv\Scripts\pythonw.exe"
pyPath  = appDir & "\venv\Scripts\python.exe"

If fso.FileExists(exePath) Then
    shell.Run """" & exePath & """", 1, False
ElseIf fso.FileExists(pywPath) Then
    shell.Run """" & pywPath & """ """ & appDir & "\desktop_app.py""", 0, False
ElseIf fso.FileExists(pyPath) Then
    shell.Run """" & pyPath & """ """ & appDir & "\desktop_app.py""", 0, False
Else
    MsgBox "Приложение еще не установлено. Запустите 1_УСТАНОВИТЬ_ПРИЛОЖЕНИЕ_WINDOWS.bat", 48, "АСУ ПУТЁВКА v6.6.0"
End If
