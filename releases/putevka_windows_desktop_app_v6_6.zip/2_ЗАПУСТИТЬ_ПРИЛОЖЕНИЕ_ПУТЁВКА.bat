@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
start "" wscript.exe "%~dp0Putevka_Desktop.vbs"
